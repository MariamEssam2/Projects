
const chatInput=document.querySelector(".chat-input textarea");
const sendChatBtn=document.querySelector(".chat-input span");
const chatbox=document.querySelector(".chatbox");
let userMessage;
const inputIniHeight=chatInput.scrollHeight;
const createChatLi=(message,className)=>{
    const chatLi=document.createElement("li");
    chatLi.classList.add("chat",className);
    let chatContent=className === "outgoing" ?`<p>${message}</p>` : `<span class="material-symbols-outlined"> psychology_alt</span><p>${message}</p>`;
    chatLi.innerHTML=chatContent;
    return chatLi;
}
const handleChat =() => {
    userMessage=chatInput.value.trim();
   if(!userMessage)return;
   chatInput.value="";
   chatInput.style.height=`${inputIniHeight}px`;
  chatbox.appendChild(createChatLi(userMessage,"outgoing"));
  chatbox.scroll(0,chatbox.scrollHeight)
}
chatInput.addEventListener("input",()=>{
    chatInput.style.height=`${inputIniHeight}px`;
    chatInput.style.height=`${chatInput.scrollHeight}px`;

})
chatInput.addEventListener("keydown",(e)=>{
if (e.key==="Enter"&&!e.shiftKey){
    e.preventDefault();
    handleChat();
}
})
sendChatBtn.addEventListener("click",handleChat);